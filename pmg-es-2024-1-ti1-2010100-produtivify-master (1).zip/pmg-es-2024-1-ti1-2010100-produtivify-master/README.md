# PRODUTIVIFY
O projeto tem como objetivo principal combater a procrastinação, um problema comum que afeta muitas pessoas em suas atividades diárias. Buscamos fornecer ferramentas e recursos para ajudar os usuários a gerenciar melhor seu tempo, estabelecer metas e acompanhar seu progresso na realização de tarefas.

## Alunos integrantes da equipe

* Thomás Ramos Oliveira
* Pedro Henrique Ferraz Lima
* Pedro Oliveira Lanza
* Pedro Afonso Machado Vasconselos
* André Segato

## Professores responsáveis

* Cleiton Silva Tavares
* Diego Augusto de Faria Barros

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
