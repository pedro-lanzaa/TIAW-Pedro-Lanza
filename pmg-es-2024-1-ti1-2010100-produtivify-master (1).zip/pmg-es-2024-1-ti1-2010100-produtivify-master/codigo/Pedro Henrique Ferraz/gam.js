let totalPoints = 0;

document.addEventListener('DOMContentLoaded', (event) => {

    totalPoints = parseInt(localStorage.getItem('totalPoints')) || 0;
    document.getElementById('total-points').textContent = totalPoints;
});

function registerActivity() {
    const activityInput = document.getElementById('activity-input');
    const activityDescription = activityInput.value;

    if (activityDescription.trim() === '') {
        alert('Por favor, descreva sua atividade.');
        return;
    }

    const activityList = document.getElementById('activity-list');
    
    const activityItem = document.createElement('div');
    activityItem.className = 'activity-item';

    const activityText = document.createElement('p');
    activityText.textContent = activityDescription;

    const rateButton = document.createElement('button');
    rateButton.className = 'btn btn-success';
    rateButton.textContent = 'Concluir Atividade';
    rateButton.onclick = () => awardPoints(activityItem);
    
    activityItem.appendChild(activityText);
    activityItem.appendChild(rateButton);

    const currentRating = document.createElement('div');
    currentRating.className = 'current-rating';
    currentRating.textContent = 'Parabéns! Você ganhou 0 pontos.';
    activityItem.appendChild(currentRating);

    activityList.appendChild(activityItem);

    activityInput.value = '';
}

function awardPoints(activityItem) {
    const points = 10;
    totalPoints += points;
    const message = `Parabéns! Você ganhou ${points} pontos. Total de pontos: ${totalPoints}`;

    const currentRating = activityItem.querySelector('.current-rating');
    currentRating.textContent = message;

    activityItem.querySelector('.btn-success').disabled = true;

    document.getElementById('total-points').textContent = totalPoints;

    localStorage.setItem('totalPoints', totalPoints);
}
