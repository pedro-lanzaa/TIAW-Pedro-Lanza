document.addEventListener("DOMContentLoaded", function() {
    const diasSemana = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
    const mesesAno = ['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'];

    const dataAtual = new Date();
    const mesAtual = dataAtual.getMonth();
    const anoAtual = dataAtual.getFullYear();

    const primeiraDataMes = new Date(anoAtual, mesAtual, 1);
    const ultimoDiaMes = new Date(anoAtual, mesAtual + 1, 0).getDate();
    const diaSemanaPrimeiraData = primeiraDataMes.getDay();

    const mesElemento = document.getElementById('mes');
    mesElemento.textContent = `${mesesAno[mesAtual]} de ${anoAtual}`;

    const numeroDiasElemento = document.querySelector('.number-days');
    let conteudoNumeroDias = '';

    for (let i = 0; i < diaSemanaPrimeiraData; i++) {
        conteudoNumeroDias += '<span class="mes-anterior"></span>';
    }

    for (let i = 1; i <= ultimoDiaMes; i++) {
        if (i === dataAtual.getDate()) {
            conteudoNumeroDias += `<span class="days-selected">${i}</span>`;
        } else {
            conteudoNumeroDias += `<span>${i}</span>`;
        }
    }

    numeroDiasElemento.innerHTML = conteudoNumeroDias;
});

