function Pomodoro() {
    this.duracaoTrabalho = 25 * 60;
    this.duracaoPausa = 5 * 60;
    this.estado = "inicio";
    this.tempoRestante = this.duracaoTrabalho;
    this.intervaloTimer = null;

    this.iniciarPomodoro = function() {
        const btnIniciar = document.getElementById('btn-iniciar');
        const btnPausar = document.getElementById('btn-pausar');
        const btnFinalizar = document.getElementById('btn-finalizar');

        btnIniciar.addEventListener('click', () => {
            if (this.estado === 'inicio') {
                this.intervaloTimer = setInterval(() => {
                    this.timer();
                    this.atualizarInterface();
                }, 1000);

                this.estado = 'trabalho';
                btnIniciar.disabled = true;
                btnPausar.disabled = false;
                btnFinalizar.disabled = false;
                this.atualizarInterface();
            }
        });

        btnPausar.addEventListener('click', () => {
            if (this.estado === 'trabalho') {
                clearInterval(this.intervaloTimer);
                this.estado = 'pausado';
                btnPausar.disabled = true;
                btnIniciar.disabled = false;
                this.atualizarInterface();
            }
        });

        btnFinalizar.addEventListener('click', () => {
            clearInterval(this.intervaloTimer);
            this.estado = 'finalizado';
            this.tempoRestante = this.duracaoTrabalho;
            btnIniciar.disabled = false;
            btnPausar.disabled = true;
            btnFinalizar.disabled = true;
            this.atualizarInterface();
        });
    };

    this.timer = function() {
        this.tempoRestante--;
        if (this.tempoRestante <= 0) {
            clearInterval(this.intervaloTimer);
            this.estado = 'finalizado';
            document.getElementById('btn-iniciar').disabled = false;
            document.getElementById('btn-pausar').disabled = true;
            document.getElementById('btn-finalizar').disabled = true;
            this.atualizarInterface();
        }
    };

    this.atualizarInterface = function() {
        const minutos = Math.floor(this.tempoRestante / 60);
        const segundos = this.tempoRestante % 60;
        document.getElementById('timer-display').textContent = `${minutos}:${segundos.toString().padStart(2, '0')}`;

        switch (this.estado) {
            case 'inicio':
                document.getElementById('status-texto').textContent = 'Pronto para iniciar';
                break;
            case 'trabalho':
                document.getElementById('status-texto').textContent = 'Trabalhando...';
                break;
            case 'pausa':
                document.getElementById('status-texto').textContent = 'Pausa';
                break;
            case 'finalizado':
                document.getElementById('status-texto').textContent = 'Pomodoro finalizado!';
                break;
        }
    };
}

const pomodoro = new Pomodoro();
pomodoro.iniciarPomodoro();
