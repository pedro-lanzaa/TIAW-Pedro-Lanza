document.addEventListener('DOMContentLoaded', function() {
    const pontosElement = document.getElementById('pontos');
    const verRealizacoesButton = document.getElementById('verRealizacoes');

    function updatePontos() {
        let pontos = localStorage.getItem('pontos');
        if (pontos === null) {
            pontos = 0;
            localStorage.setItem('pontos', pontos);
        }
        pontosElement.textContent = pontos;
    }

    verRealizacoesButton.addEventListener('click', function() {
        window.location.href = 'realizacoes.html';
    });

    updatePontos();
});
