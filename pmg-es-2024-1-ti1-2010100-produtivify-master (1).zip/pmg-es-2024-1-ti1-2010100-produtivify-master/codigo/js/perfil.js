document.addEventListener('DOMContentLoaded', function() {
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const currentUserEmail = localStorage.getItem('currentUserEmail');
    const currentUser = users.find(user => user.email === currentUserEmail);

    if (!currentUser) {
        alert('Usuário não encontrado.');
        return;
    }

    document.getElementById('profile-pic').addEventListener('click', () => {
        document.getElementById('profile-pic-input').click();
    });

    document.getElementById('profile-pic-input').addEventListener('change', (event) => {
        const reader = new FileReader();
        reader.onload = () => {
            document.getElementById('profile-pic').src = reader.result;
            localStorage.setItem(`profilePic_${currentUserEmail}`, reader.result);
        };
        reader.readAsDataURL(event.target.files[0]);
    });

    const storedProfilePic = localStorage.getItem(`profilePic_${currentUserEmail}`);
    if (storedProfilePic) {
        document.getElementById('profile-pic').src = storedProfilePic;
    }

    document.getElementById('username').innerText = currentUser.name;
    document.getElementById('user-email').innerText = currentUser.email;

    document.getElementById('edit-name-btn').addEventListener('click', () => {
        document.getElementById('edit-name-section').hidden = !document.getElementById('edit-name-section').hidden;
    });

    document.getElementById('save-name-btn').addEventListener('click', () => {
        const newName = document.getElementById('new-username').value;
        currentUser.name = newName;
        document.getElementById('username').innerText = newName;
        document.getElementById('edit-name-section').hidden = true;
        localStorage.setItem('users', JSON.stringify(users));
    });

    document.getElementById('edit-email-btn').addEventListener('click', () => {
        document.getElementById('edit-email-section').hidden = !document.getElementById('edit-email-section').hidden;
    });

    document.getElementById('save-email-btn').addEventListener('click', () => {
        const newEmail = document.getElementById('new-email').value;
        const currentPassword = document.getElementById('current-password-email').value;

        if (currentPassword !== currentUser.password) {
            alert('Senha atual incorreta.');
            return;
        }

        if (isEmailRegistered(newEmail, users)) {
            alert('Email já cadastrado.');
            return;
        }

        currentUser.email = newEmail;
        document.getElementById('user-email').innerText = newEmail;
        document.getElementById('edit-email-section').hidden = true;
        localStorage.setItem('users', JSON.stringify(users));
        localStorage.setItem('currentUserEmail', newEmail);
    });

    document.getElementById('edit-password-btn').addEventListener('click', () => {
        document.getElementById('edit-password-section').hidden = !document.getElementById('edit-password-section').hidden;
    });

    document.getElementById('save-password-btn').addEventListener('click', () => {
        const currentPassword = document.getElementById('current-password').value;
        const newPassword = document.getElementById('new-password').value;

        if (currentPassword !== currentUser.password) {
            alert('Senha atual incorreta.');
            return;
        }

        currentUser.password = newPassword;
        document.getElementById('edit-password-section').hidden = true;
        localStorage.setItem('users', JSON.stringify(users));
    });

    document.getElementById('delete-account-btn').addEventListener('click', () => {
        if (confirm('Tem certeza que deseja apagar sua conta? Esta ação não pode ser desfeita.')) {
            const userIndex = users.findIndex(user => user.email === currentUserEmail);
            users.splice(userIndex, 1);
            localStorage.setItem('users', JSON.stringify(users));
            localStorage.removeItem('currentUserEmail');
            window.location.href = 'login.html';
        }
    });

    function isEmailRegistered(email, users) {
        return users.some(user => user.email === email);
    }
});
